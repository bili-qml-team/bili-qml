// content.js

function injectQuestionButton() {
    // 检查是否已经注入过
    if (document.getElementById('bili-qmr-btn')) return;

    // 寻找转发/分享按钮所在的容器
    // B站的类名经常变动，尝试几种常见的
    const toolbar = document.querySelector('.video-toolbar-left') || 
                    document.querySelector('.toolbar-left') ||
                    document.querySelector('.video-toolbar-container .left-operations');

    if (!toolbar) return;

    // 创建问号按钮
    const qBtn = document.createElement('div');
    qBtn.id = 'bili-qmr-btn';
    qBtn.className = 'video-toolbar-left-item'; // 复用B站样式的类名
    qBtn.innerHTML = `
        <div class="qmr-icon-wrap">
            <span class="qmr-icon">?</span>
            <span class="qmr-text">问号</span>
        </div>
    `;

    // 样式处理已经在 content.css 中定义
    
    // 插入到工具栏
    // 尽量插在分享按钮后面，分享按钮通常是最后一个或倒数第二个
    toolbar.appendChild(qBtn);

    // 点击事件
    qBtn.addEventListener('click', async () => {
        const bvid = window.location.pathname.split('/')[2];
        const title = document.querySelector('.video-title')?.innerText || '未知视频';
        
        try {
            const response = await fetch('http://localhost:3000/api/vote', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ bvid, title })
            });
            const data = await response.json();
            if (data.success) {
                qBtn.classList.add('active');
                alert('已发送问号！');
            }
        } catch (error) {
            console.error('发送问号失败:', error);
            alert('发送问号失败，请确保服务器已启动。');
        }
    });
}

// 使用 MutationObserver 监听 DOM 变化，确保在 SPA 路由切换或动态加载时注入
const observer = new MutationObserver((mutations) => {
    injectQuestionButton();
});

observer.observe(document.body, {
    childList: true,
    subtree: true
});

// 初始尝试
injectQuestionButton();
